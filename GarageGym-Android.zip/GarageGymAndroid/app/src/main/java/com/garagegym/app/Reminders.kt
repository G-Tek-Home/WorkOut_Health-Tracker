package com.garagegym.app

import android.Manifest
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import org.json.JSONArray
import java.util.Calendar

/**
 * Daily/weekly reminders. The web app sends a flat list like
 * [{"id":"water0","label":"Drink water","body":"...","h":9,"m":0,"days":[0,1,2,3,4,5,6]}]
 * (days: 0 = Sunday). Each one is scheduled as its next occurrence and re-scheduled when it fires.
 * Uses inexact alarms, so a reminder can arrive a few minutes late when the phone is dozing.
 */
object Reminders {
    const val CHANNEL = "garagegym_reminders"
    private const val PREFS = "garagegym"

    fun save(ctx: Context, json: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("reminders", json).apply()
    }

    fun scheduleAll(ctx: Context) {
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val prevCount = prefs.getInt("reminders_count", 0)
        for (i in 0 until prevCount) cancel(ctx, i)
        val arr = try {
            JSONArray(prefs.getString("reminders", "[]"))
        } catch (_: Exception) {
            JSONArray()
        }
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val d = o.optJSONArray("days") ?: JSONArray()
            val days = IntArray(d.length()) { d.getInt(it) }
            schedule(ctx, i, o.optString("label"), o.optString("body"), o.optInt("h"), o.optInt("m"), days)
        }
        prefs.edit().putInt("reminders_count", arr.length()).apply()
    }

    fun schedule(ctx: Context, code: Int, label: String, body: String, h: Int, m: Int, days: IntArray) {
        val t = nextTrigger(h, m, days) ?: return
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val i = Intent(ctx, ReminderReceiver::class.java).apply {
            putExtra("code", code)
            putExtra("label", label)
            putExtra("body", body)
            putExtra("h", h)
            putExtra("m", m)
            putExtra("days", days)
        }
        val pi = PendingIntent.getBroadcast(
            ctx, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
    }

    private fun cancel(ctx: Context, code: Int) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(
            ctx, code, Intent(ctx, ReminderReceiver::class.java),
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pi != null) {
            am.cancel(pi)
            pi.cancel()
        }
    }

    private fun nextTrigger(h: Int, m: Int, days: IntArray): Long? {
        val now = System.currentTimeMillis()
        for (add in 0..7) {
            val c = Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, add)
                set(Calendar.HOUR_OF_DAY, h)
                set(Calendar.MINUTE, m)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            val dow = c.get(Calendar.DAY_OF_WEEK) - 1
            if ((days.isEmpty() || days.contains(dow)) && c.timeInMillis > now + 30_000) return c.timeInMillis
        }
        return null
    }

    fun show(ctx: Context, code: Int, label: String, body: String) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Reminders", NotificationManager.IMPORTANCE_DEFAULT)
        )
        val open = PendingIntent.getActivity(
            ctx, 0,
            Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(label)
            .setContentText(body)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(code + 1000, n)
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val code = intent.getIntExtra("code", 0)
        val label = intent.getStringExtra("label").orEmpty()
        val body = intent.getStringExtra("body").orEmpty()
        val h = intent.getIntExtra("h", 0)
        val m = intent.getIntExtra("m", 0)
        val days = intent.getIntArrayExtra("days") ?: IntArray(0)
        Reminders.show(ctx, code, label, body)
        Reminders.schedule(ctx, code, label, body, h, m, days)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) Reminders.scheduleAll(ctx)
    }
}
