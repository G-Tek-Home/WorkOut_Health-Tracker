package com.garagegym.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.ActiveCaloriesBurnedRecord
import androidx.health.connect.client.records.BasalMetabolicRateRecord
import androidx.health.connect.client.records.BloodGlucoseRecord
import androidx.health.connect.client.records.BloodPressureRecord
import androidx.health.connect.client.records.BodyFatRecord
import androidx.health.connect.client.records.BodyWaterMassRecord
import androidx.health.connect.client.records.BoneMassRecord
import androidx.health.connect.client.records.DistanceRecord
import androidx.health.connect.client.records.ExerciseSessionRecord
import androidx.health.connect.client.records.HeartRateRecord
import androidx.health.connect.client.records.HeartRateVariabilityRmssdRecord
import androidx.health.connect.client.records.HydrationRecord
import androidx.health.connect.client.records.NutritionRecord
import androidx.health.connect.client.records.OxygenSaturationRecord
import androidx.health.connect.client.records.Record
import androidx.health.connect.client.records.LeanBodyMassRecord
import androidx.health.connect.client.records.RespiratoryRateRecord
import androidx.health.connect.client.records.RestingHeartRateRecord
import androidx.health.connect.client.records.SleepSessionRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.records.TotalCaloriesBurnedRecord
import androidx.health.connect.client.records.Vo2MaxRecord
import androidx.health.connect.client.records.WeightRecord
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import androidx.lifecycle.lifecycleScope
import androidx.webkit.WebViewAssetLoader
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

class MainActivity : ComponentActivity() {

    private lateinit var webView: WebView
    private val prefs by lazy { getSharedPreferences("garagegym", Context.MODE_PRIVATE) }

    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var cameraUri: Uri? = null
    private var cameraFile: File? = null
    private var hcPendingId = -1
    private var notifPendingId = -1
    private var sharedB64: String = ""

    /** Needed for the app's core health features. */
    private val hcCore: Set<String> = setOf(
        HealthPermission.getReadPermission(StepsRecord::class),
        HealthPermission.getReadPermission(HeartRateRecord::class),
        HealthPermission.getReadPermission(RestingHeartRateRecord::class),
        HealthPermission.getReadPermission(SleepSessionRecord::class),
        HealthPermission.getReadPermission(ExerciseSessionRecord::class),
        HealthPermission.getReadPermission(ActiveCaloriesBurnedRecord::class),
        HealthPermission.getReadPermission(TotalCaloriesBurnedRecord::class)
    )

    /** Extra metrics. The app still works if you decline some of these. */
    private val hcPerms: Set<String> = hcCore + setOf(
        HealthPermission.getReadPermission(DistanceRecord::class),
        HealthPermission.getReadPermission(WeightRecord::class),
        HealthPermission.getReadPermission(HeartRateVariabilityRmssdRecord::class),
        HealthPermission.getReadPermission(OxygenSaturationRecord::class),
        HealthPermission.getReadPermission(Vo2MaxRecord::class),
        HealthPermission.getReadPermission(RespiratoryRateRecord::class),
        HealthPermission.getReadPermission(BodyFatRecord::class),
        HealthPermission.getReadPermission(LeanBodyMassRecord::class),
        HealthPermission.getReadPermission(BoneMassRecord::class),
        HealthPermission.getReadPermission(BodyWaterMassRecord::class),
        HealthPermission.getReadPermission(BasalMetabolicRateRecord::class),
        HealthPermission.getReadPermission(NutritionRecord::class),
        HealthPermission.getReadPermission(HydrationRecord::class),
        HealthPermission.getReadPermission(BloodPressureRecord::class),
        HealthPermission.getReadPermission(BloodGlucoseRecord::class)
    ) + setOf(
        // Lets the app read more than 30 days back (Health Connect 1.1+; ignored where unsupported).
        "android.permission.health.READ_HEALTH_DATA_HISTORY"
    )

    private val hcLauncher = registerForActivityResult(
        PermissionController.createRequestPermissionResultContract()
    ) { granted ->
        val id = hcPendingId
        hcPendingId = -1
        if (id >= 0) resolve(id, true, if (granted.containsAll(hcCore)) "granted" else "denied")
    }

    private val notifLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { ok ->
        val id = notifPendingId
        notifPendingId = -1
        if (id >= 0) resolve(id, true, if (ok) "granted" else "denied")
    }

    private val chooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { res -> onChooserResult(res.resultCode, res.data) }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mediaPlaybackRequiresUserGesture = true
        }

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? = assetLoader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                if (u.host == "appassets.androidplatform.net") return false
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, u))
                } catch (_: Exception) {
                }
                return true
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                val types = params.acceptTypes.filter { it.isNotBlank() && it.contains("/") }
                val wantsImage = types.any { it.startsWith("image") }
                val wantsPdf = types.any { it.contains("pdf") }
                val content = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = if (wantsImage && !wantsPdf) "image/*" else "*/*"
                    if (wantsPdf) putExtra(Intent.EXTRA_MIME_TYPES, types.toTypedArray())
                }
                val chooser = Intent.createChooser(content, "Choose a file")
                if (wantsImage) {
                    val dir = File(cacheDir, "camera").apply { mkdirs() }
                    val f = File(dir, "photo_${System.currentTimeMillis()}.jpg")
                    cameraFile = f
                    cameraUri = FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", f)
                    val cam = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                        putExtra(MediaStore.EXTRA_OUTPUT, cameraUri)
                        addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, arrayOf(cam))
                }
                return try {
                    chooserLauncher.launch(chooser)
                    true
                } catch (_: Exception) {
                    filePathCallback = null
                    false
                }
            }
        }

        webView.addJavascriptInterface(Bridge(), "Native")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                webView.evaluateJavascript(
                    "(function(){var s=document.getElementById('sheet');" +
                        "if(s&&s.classList.contains('open')){closeSheet();return 'closed'}return 'none'})()"
                ) { r -> if (r != "\"closed\"") finish() }
            }
        })

        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
        handleShare(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShare(intent)
    }

    /** A screenshot shared from another app (for example your scale app) is downscaled and handed to the page. */
    private fun handleShare(i: Intent?) {
        if (i?.action != Intent.ACTION_SEND || i.type?.startsWith("image/") != true) return
        val uri: Uri? = if (Build.VERSION.SDK_INT >= 33) {
            i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        } else {
            @Suppress("DEPRECATION") i.getParcelableExtra(Intent.EXTRA_STREAM)
        }
        if (uri == null) return
        Thread {
            try {
                contentResolver.openInputStream(uri)?.use { ins ->
                    val bytes = ins.readBytes()
                    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                    var sample = 1
                    while (bounds.outWidth / sample > 1600 || bounds.outHeight / sample > 1600) sample *= 2
                    val bmp = BitmapFactory.decodeByteArray(
                        bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample }
                    ) ?: return@use
                    val out = ByteArrayOutputStream()
                    bmp.compress(Bitmap.CompressFormat.JPEG, 88, out)
                    sharedB64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
                    runOnUiThread {
                        webView.evaluateJavascript(
                            "window.__native&&window.__native.shared&&window.__native.shared()", null
                        )
                    }
                }
            } catch (_: Exception) {
            }
        }.start()
    }

    override fun onPause() {
        super.onPause()
        webView.onPause()
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
    }

    private fun onChooserResult(code: Int, data: Intent?) {
        val cb = filePathCallback ?: return
        filePathCallback = null
        if (code != Activity.RESULT_OK) {
            cb.onReceiveValue(null)
            return
        }
        val picked = data?.data
        if (picked != null) {
            cb.onReceiveValue(arrayOf(picked))
            return
        }
        val cam = cameraUri
        val file = cameraFile
        if (cam != null && file != null && file.length() > 0) {
            cb.onReceiveValue(arrayOf(cam))
        } else {
            cb.onReceiveValue(null)
        }
    }

    /** Sends an async result back to the page: window.__native.cb(id, ok, payload) */
    private fun resolve(id: Int, ok: Boolean, payload: String) {
        val js = "window.__native&&window.__native.cb($id,$ok,${JSONObject.quote(payload)})"
        runOnUiThread { webView.evaluateJavascript(js, null) }
    }

    inner class Bridge {

        @JavascriptInterface
        fun flavor(): String = "full"

        // ---- Claude (your own Anthropic API key) ----
        @JavascriptInterface
        fun hasKey(): Boolean = !prefs.getString("key", "").isNullOrBlank()

        @JavascriptInterface
        fun setKey(key: String) {
            prefs.edit().putString("key", key.trim()).apply()
        }

        @JavascriptInterface
        fun getModel(): String = prefs.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL

        @JavascriptInterface
        fun setModel(model: String) {
            prefs.edit().putString("model", model.trim().ifEmpty { DEFAULT_MODEL }).apply()
        }

        @JavascriptInterface
        fun ask(id: Int, prompt: String, imagesJson: String, tier: String) {
            Thread {
                try {
                    resolve(id, true, callClaude(prompt, imagesJson))
                } catch (e: Exception) {
                    resolve(id, false, e.message ?: "error")
                }
            }.start()
        }

        // ---- Health Connect (Garmin data arrives here through the Garmin Connect app) ----
        @JavascriptInterface
        fun healthStatus(): String {
            if (HealthConnectClient.getSdkStatus(this@MainActivity) != HealthConnectClient.SDK_AVAILABLE) {
                return "unavailable"
            }
            return try {
                runBlocking {
                    val granted = HealthConnectClient.getOrCreate(this@MainActivity)
                        .permissionController.getGrantedPermissions()
                    if (granted.containsAll(hcCore)) "granted" else "needs_permission"
                }
            } catch (_: Exception) {
                "unavailable"
            }
        }

        @JavascriptInterface
        fun requestHealth(id: Int) {
            runOnUiThread {
                if (HealthConnectClient.getSdkStatus(this@MainActivity) != HealthConnectClient.SDK_AVAILABLE) {
                    resolve(id, true, "unavailable")
                } else {
                    hcPendingId = id
                    hcLauncher.launch(hcPerms)
                }
            }
        }

        @JavascriptInterface
        fun syncHealth(id: Int, days: Int, optsJson: String) {
            lifecycleScope.launch(Dispatchers.IO) {
                try {
                    val opts = try { JSONObject(optsJson) } catch (_: Exception) { JSONObject() }
                    resolve(id, true, readHealth(days.coerceIn(1, 365), opts))
                } catch (e: SecurityException) {
                    resolve(id, false, "permission")
                } catch (e: Exception) {
                    resolve(id, false, e.message ?: "error")
                }
            }
        }

        // ---- PDF lab reports: render pages to JPEG so Claude can read them as images ----
        @JavascriptInterface
        fun pdfPages(id: Int, b64: String, maxPages: Int) {
            Thread {
                try {
                    val f = File(cacheDir, "report_${System.currentTimeMillis()}.pdf")
                    f.writeBytes(Base64.decode(b64, Base64.DEFAULT))
                    val pfd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
                    val renderer = PdfRenderer(pfd)
                    val out = JSONArray()
                    for (i in 0 until minOf(renderer.pageCount, maxPages)) {
                        val page = renderer.openPage(i)
                        val scale = 1500f / maxOf(page.width, page.height)
                        val bmp = Bitmap.createBitmap(
                            (page.width * scale).toInt().coerceAtLeast(1),
                            (page.height * scale).toInt().coerceAtLeast(1),
                            Bitmap.Config.ARGB_8888
                        )
                        Canvas(bmp).drawColor(Color.WHITE)
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        page.close()
                        val baos = ByteArrayOutputStream()
                        bmp.compress(Bitmap.CompressFormat.JPEG, 85, baos)
                        out.put(Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP))
                    }
                    renderer.close()
                    pfd.close()
                    f.delete()
                    resolve(id, true, out.toString())
                } catch (e: Exception) {
                    resolve(id, false, e.message ?: "Could not open the PDF")
                }
            }.start()
        }

        // ---- Shared screenshot + launching other apps ----
        @JavascriptInterface
        fun takeShared(): String {
            val v = sharedB64
            sharedB64 = ""
            return v
        }

        @JavascriptInterface
        fun openApp(label: String): Boolean {
            val q = label.trim().lowercase()
            if (q.isEmpty()) return false
            val pm = packageManager
            val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = if (Build.VERSION.SDK_INT >= 33) {
                pm.queryIntentActivities(main, PackageManager.ResolveInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION") pm.queryIntentActivities(main, 0)
            }
            val hit = list.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) } ?: return false
            val launch = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return false
            runOnUiThread { startActivity(launch) }
            return true
        }

        // ---- Barcode: ML Kit reads the code from a photo, Open Food Facts supplies the nutrition ----
        @JavascriptInterface
        fun scanBarcode(id: Int, b64: String) {
            Thread {
                try {
                    val bytes = Base64.decode(b64, Base64.DEFAULT)
                    val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                        ?: throw IllegalStateException("Could not read the photo")
                    val opts = BarcodeScannerOptions.Builder()
                        .setBarcodeFormats(
                            Barcode.FORMAT_EAN_13, Barcode.FORMAT_EAN_8,
                            Barcode.FORMAT_UPC_A, Barcode.FORMAT_UPC_E
                        ).build()
                    BarcodeScanning.getClient(opts).process(InputImage.fromBitmap(bmp, 0))
                        .addOnSuccessListener { list ->
                            val code = list.firstOrNull()?.rawValue
                            if (code == null) {
                                resolve(id, true, "{\"error\":\"nobarcode\"}")
                            } else {
                                Thread {
                                    try {
                                        resolve(id, true, lookupOff(code))
                                    } catch (e: Exception) {
                                        resolve(id, false, e.message ?: "error")
                                    }
                                }.start()
                            }
                        }
                        .addOnFailureListener { resolve(id, true, "{\"error\":\"nobarcode\"}") }
                } catch (e: Exception) {
                    resolve(id, false, e.message ?: "error")
                }
            }.start()
        }

        @JavascriptInterface
        fun lookupBarcode(id: Int, code: String) {
            Thread {
                try {
                    resolve(id, true, lookupOff(code.filter { it.isDigit() }))
                } catch (e: Exception) {
                    resolve(id, false, e.message ?: "error")
                }
            }.start()
        }

        // ---- Reminders (notifications) ----
        @JavascriptInterface
        fun setReminders(json: String) {
            Reminders.save(this@MainActivity, json)
            Reminders.scheduleAll(this@MainActivity)
        }

        @JavascriptInterface
        fun notifStatus(): String =
            if (Build.VERSION.SDK_INT < 33 ||
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            ) "granted" else "needed"

        @JavascriptInterface
        fun requestNotif(id: Int) {
            runOnUiThread {
                if (Build.VERSION.SDK_INT < 33) {
                    resolve(id, true, "granted")
                } else {
                    notifPendingId = id
                    notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }
        }

        // ---- Backup export via the Android share sheet ----
        @JavascriptInterface
        fun share(filename: String, text: String) {
            runOnUiThread {
                try {
                    val dir = File(cacheDir, "backup").apply { mkdirs() }
                    val f = File(dir, filename.replace(Regex("[^A-Za-z0-9._-]"), "_"))
                    f.writeText(text)
                    val uri = FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", f)
                    val i = Intent(Intent.ACTION_SEND).apply {
                        type = "application/json"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        putExtra(Intent.EXTRA_SUBJECT, filename)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    startActivity(Intent.createChooser(i, "Save backup"))
                } catch (_: Exception) {
                }
            }
        }
    }

    // ---------- Claude API ----------
    private fun callClaude(prompt: String, imagesJson: String): String {
        val key = prefs.getString("key", "").orEmpty()
        if (key.isBlank()) throw IllegalStateException("nokey")
        val model = prefs.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL

        val content = JSONArray()
        val imgs = JSONArray(imagesJson)
        for (i in 0 until imgs.length()) {
            val b64 = imgs.getString(i)
            if (b64.isNotEmpty()) {
                content.put(
                    JSONObject()
                        .put("type", "image")
                        .put(
                            "source",
                            JSONObject()
                                .put("type", "base64")
                                .put("media_type", "image/jpeg")
                                .put("data", b64)
                        )
                )
            }
        }
        content.put(JSONObject().put("type", "text").put("text", prompt))

        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 4096)
            .put(
                "messages",
                JSONArray().put(JSONObject().put("role", "user").put("content", content))
            )

        val conn = (URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 20000
            readTimeout = 120000
            setRequestProperty("content-type", "application/json")
            setRequestProperty("x-api-key", key)
            setRequestProperty("anthropic-version", "2023-06-01")
        }
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        when {
            code == 401 || code == 403 -> throw IllegalStateException("nokey")
            code == 429 -> throw IllegalStateException("ratelimit")
            code !in 200..299 -> throw IllegalStateException("http $code")
        }
        val arr = JSONObject(text).getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until arr.length()) {
            val part = arr.getJSONObject(i)
            if (part.optString("type") == "text") sb.append(part.optString("text"))
        }
        return sb.toString()
    }

    // ---------- Open Food Facts ----------
    private fun lookupOff(rawCode: String): String {
        val code = if (rawCode.length == 12) "0$rawCode" else rawCode
        val url = URL(
            "https://world.openfoodfacts.org/api/v2/product/$code.json" +
                "?fields=product_name,brands,serving_size,serving_quantity,nutriments,ingredients_text"
        )
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15000
            readTimeout = 20000
            setRequestProperty("User-Agent", "GarageGym/1.0 (Android)")
        }
        val notFound = JSONObject().put("error", "not found").put("code", code).toString()
        if (conn.responseCode !in 200..299) return notFound
        val root = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
        if (root.optInt("status") != 1) return notFound
        val p = root.getJSONObject("product")
        val n = p.optJSONObject("nutriments") ?: JSONObject()
        fun d(k: String): Double = n.optDouble(k, 0.0).let { if (it.isNaN()) 0.0 else it }
        val per100 = JSONObject()
            .put("kcal", d("energy-kcal_100g"))
            .put("protein", d("proteins_100g"))
            .put("carbs", d("carbohydrates_100g"))
            .put("fiber", d("fiber_100g"))
            .put("fat", d("fat_100g"))
            .put("polyols", d("polyols_100g"))
            .put("sodiumMg", d("sodium_100g") * 1000.0)
        return JSONObject()
            .put("code", code)
            .put("name", p.optString("product_name"))
            .put("brand", p.optString("brands"))
            .put("serving", p.optString("serving_size"))
            .put("servingG", p.optDouble("serving_quantity", 0.0).let { if (it.isNaN()) 0.0 else it })
            .put("per100", per100)
            .put("ingredients", p.optString("ingredients_text"))
            .toString()
    }

    // ---------- Health Connect reader ----------
    private inline fun <T> optional(block: () -> T?): T? =
        try {
            block()
        } catch (_: Exception) {
            null
        }

    private suspend fun readHealth(days: Int, opts: JSONObject): String {
        val client = HealthConnectClient.getOrCreate(this)
        val pref = opts.optString("pref")

        /** If you chose a preferred source (Samsung Health or Garmin Connect) use only its records when it has any. */
        fun <T : Record> pick(l: List<T>): List<T> {
            if (pref.isNotEmpty()) {
                val f = l.filter { it.metadata.dataOrigin.packageName == pref }
                if (f.isNotEmpty()) return f
            }
            return l
        }

        val zone = ZoneId.systemDefault()
        val firstDay = LocalDate.now(zone).minusDays((days - 1).toLong())
        val rangeStart = firstDay.atStartOfDay(zone).toInstant()
        val rangeEnd = Instant.now()

        val daysArr = JSONArray()
        for (d in 0 until days) {
            val day = firstDay.plusDays(d.toLong())
            val s = day.atStartOfDay(zone).toInstant()
            val e = day.plusDays(1).atStartOfDay(zone).toInstant()
            val range = TimeRangeFilter.between(s, e)
            val o = JSONObject().put("day", day.toString())

            // Steps are required: a missing permission throws and the page asks you to reconnect.
            val steps = client.aggregate(
                AggregateRequest(metrics = setOf(StepsRecord.COUNT_TOTAL), timeRangeFilter = range)
            )[StepsRecord.COUNT_TOTAL] ?: 0L
            o.put("steps", steps)

            optional {
                client.aggregate(
                    AggregateRequest(metrics = setOf(DistanceRecord.DISTANCE_TOTAL), timeRangeFilter = range)
                )[DistanceRecord.DISTANCE_TOTAL]?.inMeters
            }?.let { o.put("dist", it) }

            optional {
                client.aggregate(
                    AggregateRequest(
                        metrics = setOf(ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL),
                        timeRangeFilter = range
                    )
                )[ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL]?.inKilocalories
            }?.let { o.put("akcal", it) }

            optional {
                val l = pick(client.readRecords(ReadRecordsRequest(RestingHeartRateRecord::class, range)).records).map { it.beatsPerMinute }
                if (l.isEmpty()) null else l.average().toInt()
            }?.let { o.put("rhr", it) }

            optional {
                val l = pick(client.readRecords(ReadRecordsRequest(HeartRateVariabilityRmssdRecord::class, range)).records).map { it.heartRateVariabilityMillis }
                if (l.isEmpty()) null else l.average()
            }?.let { o.put("hrv", it) }

            optional {
                val l = pick(client.readRecords(ReadRecordsRequest(OxygenSaturationRecord::class, range)).records).map { it.percentage.value }
                if (l.isEmpty()) null else l.average()
            }?.let { o.put("spo2", it) }

            optional {
                val l = pick(client.readRecords(ReadRecordsRequest(RespiratoryRateRecord::class, range)).records).map { it.rate }
                if (l.isEmpty()) null else l.average()
            }?.let { o.put("resp", it) }

            optional {
                pick(client.readRecords(ReadRecordsRequest(WeightRecord::class, range)).records).maxByOrNull { it.time }?.weight?.inKilograms
            }?.let { o.put("wkg", it) }

            optional {
                pick(client.readRecords(ReadRecordsRequest(BodyFatRecord::class, range)).records).maxByOrNull { it.time }?.percentage?.value
            }?.let { o.put("bf", it) }

            optional {
                pick(client.readRecords(ReadRecordsRequest(LeanBodyMassRecord::class, range)).records).maxByOrNull { it.time }?.mass?.inKilograms
            }?.let { o.put("lean", it) }

            optional {
                pick(client.readRecords(ReadRecordsRequest(BoneMassRecord::class, range)).records).maxByOrNull { it.time }?.mass?.inKilograms
            }?.let { o.put("bone", it) }

            optional {
                pick(client.readRecords(ReadRecordsRequest(BodyWaterMassRecord::class, range)).records).maxByOrNull { it.time }?.mass?.inKilograms
            }?.let { o.put("water", it) }

            optional {
                pick(client.readRecords(ReadRecordsRequest(BasalMetabolicRateRecord::class, range)).records).maxByOrNull { it.time }?.basalMetabolicRate?.inKilocaloriesPerDay
            }?.let { o.put("bmr", it) }

            optional {
                pick(client.readRecords(ReadRecordsRequest(Vo2MaxRecord::class, range)).records).maxByOrNull { it.time }?.vo2MillilitersPerMinuteKilogram
            }?.let { o.put("vo2", it) }

            if (opts.optBoolean("water", true)) {
                optional {
                    client.aggregate(
                        AggregateRequest(metrics = setOf(HydrationRecord.VOLUME_TOTAL), timeRangeFilter = range)
                    )[HydrationRecord.VOLUME_TOTAL]?.inMilliliters
                }?.let { o.put("hyd", it) }
            }

            if (opts.optBoolean("vitals", true)) {
                optional {
                    pick(client.readRecords(ReadRecordsRequest(BloodPressureRecord::class, range)).records)
                        .maxByOrNull { it.time }
                }?.let {
                    o.put("bps", it.systolic.inMillimetersOfMercury)
                    o.put("bpd", it.diastolic.inMillimetersOfMercury)
                }
                optional {
                    val l = pick(client.readRecords(ReadRecordsRequest(BloodGlucoseRecord::class, range)).records)
                        .map { it.level.inMillimolesPerLiter }
                    if (l.isEmpty()) null else l.average()
                }?.let { o.put("gluc", it) }
            }

            optional {
                val sleepRange = TimeRangeFilter.between(s.minus(Duration.ofHours(12)), e)
                val allSleep = client.readRecords(ReadRecordsRequest(SleepSessionRecord::class, sleepRange))
                    .records.filter { it.endTime >= s && it.endTime < e }
                // Two apps can report the same night. Use one source so it is not counted twice.
                val groups = allSleep.groupBy { it.metadata.dataOrigin.packageName }
                val recs = (if (pref.isNotEmpty() && groups.containsKey(pref)) groups[pref]
                else groups.values.maxByOrNull { g -> g.sumOf { Duration.between(it.startTime, it.endTime).toMinutes() } })
                    ?: emptyList()
                if (recs.isNotEmpty()) {
                    var deep = 0L
                    var rem = 0L
                    var light = 0L
                    var awake = 0L
                    var asleep = 0L
                    for (r in recs) {
                        if (r.stages.isEmpty()) {
                            asleep += Duration.between(r.startTime, r.endTime).toMinutes()
                        } else {
                            for (st in r.stages) {
                                val mins = Duration.between(st.startTime, st.endTime).toMinutes()
                                when (st.stage) {
                                    SleepSessionRecord.STAGE_TYPE_DEEP -> { deep += mins; asleep += mins }
                                    SleepSessionRecord.STAGE_TYPE_REM -> { rem += mins; asleep += mins }
                                    SleepSessionRecord.STAGE_TYPE_LIGHT -> { light += mins; asleep += mins }
                                    SleepSessionRecord.STAGE_TYPE_SLEEPING -> asleep += mins
                                    SleepSessionRecord.STAGE_TYPE_AWAKE,
                                    SleepSessionRecord.STAGE_TYPE_AWAKE_IN_BED,
                                    SleepSessionRecord.STAGE_TYPE_OUT_OF_BED -> awake += mins
                                    else -> {}
                                }
                            }
                        }
                    }
                    val first = recs.minByOrNull { it.startTime }!!
                    val local = first.startTime.atZone(zone)
                    // Minutes after 6 pm, so a bedtime of 11 pm or 1 am sits on one continuous scale.
                    val bed = (local.hour * 60 + local.minute - 18 * 60 + 1440) % 1440
                    o.put("sleep", Math.round(asleep / 6.0) / 10.0)
                    if (deep + rem + light > 0) {
                        o.put("deep", deep).put("rem", rem).put("light", light)
                    }
                    o.put("awake", awake).put("bed", bed)
                }
            }
            daysArr.put(o)
        }

        val actArr = JSONArray()
        val sessions = pick(
            client.readRecords(
                ReadRecordsRequest(ExerciseSessionRecord::class, TimeRangeFilter.between(rangeStart, rangeEnd))
            ).records
        )
        for (r in sessions) {
            val rr = TimeRangeFilter.between(r.startTime, r.endTime)
            val total = optional {
                client.aggregate(
                    AggregateRequest(metrics = setOf(TotalCaloriesBurnedRecord.ENERGY_TOTAL), timeRangeFilter = rr)
                )[TotalCaloriesBurnedRecord.ENERGY_TOTAL]?.inKilocalories
            }
            val active = optional {
                client.aggregate(
                    AggregateRequest(
                        metrics = setOf(ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL),
                        timeRangeFilter = rr
                    )
                )[ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL]?.inKilocalories
            }
            val hr = optional {
                client.aggregate(
                    AggregateRequest(metrics = setOf(HeartRateRecord.BPM_AVG), timeRangeFilter = rr)
                )[HeartRateRecord.BPM_AVG]
            } ?: 0L

            actArr.put(
                JSONObject()
                    .put("start", r.startTime.toEpochMilli())
                    .put("end", r.endTime.toEpochMilli())
                    .put("type", ExerciseSessionRecord.EXERCISE_TYPE_INT_TO_STRING_MAP[r.exerciseType] ?: "other")
                    .put("title", r.title ?: "")
                    .put("kcal", total ?: active ?: 0.0)
                    .put("hr", hr)
            )
        }
        val bpArr = JSONArray()
        if (opts.optBoolean("vitals", true)) {
            optional {
                pick(
                    client.readRecords(
                        ReadRecordsRequest(BloodPressureRecord::class, TimeRangeFilter.between(rangeStart, rangeEnd))
                    ).records
                ).forEach { r ->
                    bpArr.put(
                        JSONObject()
                            .put("ts", r.time.toEpochMilli())
                            .put("s", r.systolic.inMillimetersOfMercury)
                            .put("d", r.diastolic.inMillimetersOfMercury)
                    )
                }
                true
            }
        }
        val nutrition = JSONArray()
        if (opts.optBoolean("food", false)) {
            optional {
                client.readRecords(
                    ReadRecordsRequest(NutritionRecord::class, TimeRangeFilter.between(rangeStart, rangeEnd))
                ).records.forEach { r ->
                    val kcal = r.energy?.inKilocalories ?: 0.0
                    if (kcal > 0) {
                        nutrition.put(
                            JSONObject()
                                .put("id", r.metadata.id)
                                .put("ts", r.startTime.toEpochMilli())
                                .put("name", r.name ?: "Food")
                                .put("kcal", kcal)
                                .put("p", r.protein?.inGrams ?: 0.0)
                                .put("c", r.totalCarbohydrate?.inGrams ?: 0.0)
                                .put("fi", r.dietaryFiber?.inGrams ?: 0.0)
                                .put("f", r.totalFat?.inGrams ?: 0.0)
                        )
                    }
                }
                true
            }
        }
        return JSONObject().put("days", daysArr).put("activities", actArr).put("nutrition", nutrition).put("bp", bpArr).toString()
    }

    companion object {
        const val DEFAULT_MODEL = "claude-sonnet-5-5"
    }
}
